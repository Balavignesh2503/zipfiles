<?php require_once('./config.php'); ?>
<!DOCTYPE html>
<html lang="en" style="height: auto;">
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    #header {
      height: 70vh;
      position: relative;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
    }
    #header:before {
      content: "";
      position: absolute;
      top: 0;
      left: 0;
      height: 100%;
      width: 100%;
      background-image: url(<?= validate_image($_settings->info("cover")) ?>);
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      z-index: 1;
      filter: brightness(0.7);
    }
    #header .content {
      position: relative;
      z-index: 2;
      text-align: center;
    }
    footer {
      background: #343a40;
      color: #fff;
      padding: 20px 0;
    }
    footer a {
      color: #ffdd57;
      text-decoration: none;
    }
    footer a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body class="layout-top-nav layout-fixed layout-navbar-fixed" style="height: auto;">
  <div class="wrapper">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow">
      <div class="container">
        <a class="navbar-brand" href="#">MyWebsite</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a class="nav-link" href="?page=home">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="?page=about_us">About Us</a></li>
            <li class="nav-item"><a class="nav-link" href="?page=contact">Contact</a></li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <?php if($page == "home" || $page == "about_us"): ?>
      <div id="header" class="shadow mb-4">
        <div class="content">
          <h1>Welcome to MyWebsite</h1>
          <p>Your gateway to amazing experiences.</p>
        </div>
      </div>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="content-wrapper pt-3" style="min-height: 567.854px;">
      <section class="content">
        <div class="container">
          <?php 
            if(!file_exists($page.".php") && !is_dir($page)){
              include '404.html';
            }else{
              if(is_dir($page))
                include $page.'/index.php';
              else
                include $page.'.php';
            }
          ?>
        </div>
      </section>
    </div>

    <!-- Footer -->
    <footer class="text-center">
      <div class="container">
        <p>&copy; 2025 MyWebsite. All Rights Reserved. | <a href="?page=privacy">Privacy Policy</a></p>
      </div>
    </footer>

    <!-- Modals -->
    <?php include('inc/modals.php'); ?>
  </div>
</body>
</html>
