<?php
    include_once 'import/header.php';
?>


<?php
    include_once 'import/heading.php';
?>


<?php
    include_once 'import/select.php';
?>  
          
    <!-- this section is hidden. only applied when user clicked sign up or login button -->
    <?php
    include_once 'login.php';
    ?>
    

<?php
    include_once 'import/footer.php';
?>