<?php
    $server = "localhost";
    $un = "root";
    $pw ="";
    $db = "flymaster_login";

    $conn = mysqli_connect($server,$un,$pw,$db);


?>


