</div>

        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col">
                        <h4>Fly Master</h4>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="bookticket.php">Ticket Bookings</a></li>
                            <li><a href="contactus.php">Contact Us</a></li>
                            <li><a href="aboutus.php">About Us</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>get help</h4>
                        <ul>
                            <li><a href="search.php">Search Flight</a></li>
                            <li><a href="manage.php">Manage Bookings</a></li>
                            <li><a href="checkin.php">Check In</a></li>
                            <li><a href="status.php">Flight Status</a></li>
                            <li><a href="contactus.php">payment options</a></li>
                        </ul>
                    </div>
                    <div class="footer-col">
                        <h4>Fly Master App</h4>
                        <ul>
                            <li><a href="https://play.google.com/" target="_blank"><img src="images/playstore.png" alt="Play Store Butto" class="playstore"></a></li>
                            <li><a href="https://www.apple.com/app-store/" target="_blank"><img src="images/appstore.png" alt="App Store" class="appstore"></a></li>
                        </ul>
                    </div>
                    <div class="footer-col ml-auto">
                        <h4>follow us</h4>
                        <div class="social-links">
                            <a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter"></i></a>
                            <a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram"></i></a>
                            <a href="https://www.youtube.com/" target="_blank"><i class="fa fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
            </div>
       </footer>    
      
      
			
</body>
</html>